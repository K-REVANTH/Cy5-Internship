<h1 align=center>CLOSEC - CLI</h1>

Automated scanner, that scans for you finding out the vulnerabilities, secrets in your projects, images and more...

