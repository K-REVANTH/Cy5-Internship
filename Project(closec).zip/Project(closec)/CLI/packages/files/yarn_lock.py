def scan_yarn_lock(file):
    print("Ugh-Oh, there is some error with Yarn, dev on the way, check back shortly...")
