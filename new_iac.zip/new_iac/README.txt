INSTRUCTIONS FOR RUNNING THE CODE:

To execute the scripts for scanning Infrastructure as Code (IAC) misconfigurations, follow the steps below. Ensure you are running the terminal as an administrator:

1. Convert Terraform file to a JSON file.
    - Run the "terraform_to_json.py" script.
    - When prompted, provide the path to the Terraform file (e.g., sample.tf).
    - Specify a name for the output JSON file (e.g., output.json), where the converted Terraform data will be stored.

2. Run IAC Misconfiguration Scanner:
    - Execute the "iac_misconfigurations_scanner.py" script.
    - When prompted, provide the path to the Terraform file (e.g., sample.tf) to initiate the scanning process.
    - The script will perform all IAC misconfiguration checks, and the results will be displayed in the terminal.