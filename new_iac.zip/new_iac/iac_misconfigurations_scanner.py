import os
from scanners import (security_group_rules, hardcoded_credentials, encryption,
                      unrestricted_s3_buckets, iam_roles, network_acls,
                      logging_monitoring, security_patches, autoscaling_groups,
                      cloud_storage, database_access, egress_rules,
                      resource_tagging, backups, management_interfaces,
                      public_ips, container_configuration, secrets_management,
                      security_features, cloud_best_practices)

# List of available checks
CHECKS = {
    "1": security_group_rules.check,
    "2": hardcoded_credentials.check,
    "3": encryption.check,
    "4": unrestricted_s3_buckets.check,
    "5": iam_roles.check,
    "6": network_acls.check,
    "7": logging_monitoring.check,
    "8": security_patches.check,
    "9": autoscaling_groups.check,
    "10": cloud_storage.check,
    "11": database_access.check,
    "12": egress_rules.check,
    "13": resource_tagging.check,
    "14": backups.check,
    "15": management_interfaces.check,
    "16": public_ips.check,
    "17": container_configuration.check,
    "18": secrets_management.check,
    "19": security_features.check,
    "20": cloud_best_practices.check,
}

def main():
    tf_file = input("Enter the path to the Terraform (.tf) file: ")

    if not os.path.exists(tf_file):
        print("Terraform file not found!")
        return

    print("\n RUNNING IAC MISCONFIGURATION CHECKS : \n")

    for key, check in CHECKS.items():
        print(f"\nRunning check for: {check.__module__.split('.')[-1].replace('_', ' ').title()}...")
        check(tf_file)

    print("\n ALL CHECKS COMPLETED")

if __name__ == "__main__":
    main()
