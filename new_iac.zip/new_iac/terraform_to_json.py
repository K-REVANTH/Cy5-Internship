import hcl2
import json

def parse_terraform(file_path):
    """
    Parses a Terraform file (in HCL format) and converts it into an efficient nested JSON format.
    """
    with open(file_path, 'r') as file:
        terraform_data = hcl2.load(file)

    # Ensure the data is a dictionary for consistent processing
    if isinstance(terraform_data, list):
        terraform_data = terraform_data[0]

    final_json = {}

    # If 'resource' is in the loaded data
    if 'resource' in terraform_data:
        resources = terraform_data['resource']

        # Iterate through each resource
        for resource in resources:
            for resource_type, resource_dict in resource.items():
                if resource_type not in final_json:
                    final_json[resource_type] = []

                # Handle each resource instance
                for resource_name, resource_values in resource_dict.items():
                    resource_data = {"resource_name": resource_name}

                    # Call specific handler function based on resource type
                    if resource_type == "aws_security_group":
                        resource_data = handle_aws_security_group(resource_values, resource_data)
                    elif resource_type == "aws_s3_bucket":
                        resource_data = handle_aws_s3_bucket(resource_values, resource_data)
                    elif resource_type == "aws_lambda_function":
                        resource_data = handle_aws_lambda_function(resource_values, resource_data)
                    elif resource_type == "aws_iam_role_policy":
                        resource_data = handle_aws_iam_role_policy(resource_values, resource_data)
                    elif resource_type == "aws_ec2_instance":
                        resource_data = handle_aws_ec2_instance(resource_values, resource_data)
                    elif resource_type == "aws_rds_instance":
                        resource_data = handle_aws_rds_instance(resource_values, resource_data)
                    elif resource_type == "aws_ebs_volume":
                        resource_data = handle_aws_ebs_volume(resource_values, resource_data)
                    elif resource_type == "aws_network_acl":
                        resource_data = handle_aws_network_acl(resource_values, resource_data)
                    elif resource_type == "aws_autoscaling_group":
                        resource_data = handle_aws_autoscaling_group(resource_values, resource_data)
                    elif resource_type == "aws_rds_cluster":
                        resource_data = handle_aws_rds_cluster(resource_values, resource_data)
                    elif resource_type == "aws_ecs_task_definition":
                        resource_data = handle_aws_ecs_task_definition(resource_values, resource_data)

                    # Append the processed resource data to the final JSON output
                    final_json[resource_type].append(resource_data)

    return final_json



# Handlers for each resource type
def handle_aws_security_group(resource_values, resource_data):
    """
    Handle parsing for aws_security_group resource type.
    """
    resource_data["security_group_id"] = resource_values.get("security_group_id")
    resource_data["security_group_name"] = resource_values.get("security_group_name")
    resource_data["description"] = resource_values.get("description")
    resource_data["vpc_id"] = resource_values.get("vpc_id")
    resource_data["owner_id"] = resource_values.get("owner_id")
    resource_data["tags"] = resource_values.get("tags", {})

    # Add Ingress Rules
    resource_data["ingress_rules"] = []
    if "ingress" in resource_values:
        for ingress_rule in resource_values["ingress"]:
            rule = {
                "from_port": ingress_rule.get("from_port"),
                "to_port": ingress_rule.get("to_port"),
                "protocol": ingress_rule.get("protocol"),
                "cidr_blocks": ingress_rule.get("cidr_blocks", []),
                "ipv6_cidr_blocks": ingress_rule.get("ipv6_cidr_blocks", []),
                "source_security_group": ingress_rule.get("source_security_group_id")
            }
            resource_data["ingress_rules"].append(rule)

    # Add Egress Rules
    resource_data["egress_rules"] = []
    if "egress" in resource_values:
        for egress_rule in resource_values["egress"]:
            rule = {
                "from_port": egress_rule.get("from_port"),
                "to_port": egress_rule.get("to_port"),
                "protocol": egress_rule.get("protocol"),
                "cidr_blocks": egress_rule.get("cidr_blocks", []),
                "ipv6_cidr_blocks": egress_rule.get("ipv6_cidr_blocks", []),
                "destination_security_group": egress_rule.get("destination_security_group_id")
            }
            resource_data["egress_rules"].append(rule)

    return resource_data



def handle_aws_s3_bucket(resource_values, resource_data):
    resource_data["bucket_name"] = resource_values.get("bucket")
    resource_data["acl"] = resource_values.get("acl")
    resource_data["logging"] = resource_values.get("logging", {})

    versioning = resource_values.get("versioning", [])
    if isinstance(versioning, list) and versioning:
        resource_data["versioning"] = versioning[0].get("enabled", False)
    else:
        resource_data["versioning"] = versioning.get("enabled", False) if isinstance(versioning, dict) else False

    # Handle server-side encryption
    encryption_config = resource_values.get("server_side_encryption_configuration", [])
    if encryption_config and isinstance(encryption_config, list):
        encryption_rule = encryption_config[0].get("rule", [])

        # If rule is a list, access the first element
        if encryption_rule and isinstance(encryption_rule, list):
            encryption_defaults = encryption_rule[0].get("apply_server_side_encryption_by_default", {})
        else:
            encryption_defaults = encryption_rule.get("apply_server_side_encryption_by_default", {})

        # Make sure encryption_defaults is a dict before using .get()
        if isinstance(encryption_defaults, dict):
            resource_data["encryption"] = encryption_defaults.get("sse_algorithm", "None")
        else:
            resource_data["encryption"] = "None"
    else:
        resource_data["encryption"] = "None"

    return resource_data



def handle_aws_lambda_function(resource_values, resource_data):
    """
    Handle parsing for aws_lambda_function resource type.
    """
    resource_data["function_name"] = resource_values.get("function_name")
    resource_data["runtime"] = resource_values.get("runtime")
    resource_data["handler"] = resource_values.get("handler")
    # resource_data["environment"] = resource_values.get("environment", {}).get("variables", {})
    # Handle environment variables
    environment = resource_values.get("environment", {})

    # Check if environment is a dict, then get 'variables', otherwise use empty dict
    if isinstance(environment, dict):
        resource_data["environment"] = environment.get("variables", {})
    else:
        resource_data["environment"] = {}

    resource_data["memory_size"] = resource_values.get("memory_size", 128)
    resource_data["timeout"] = resource_values.get("timeout", 3)
    resource_data["vpc_config"] = resource_values.get("vpc_config", {})
    resource_data["layers"] = resource_values.get("layers", [])
    resource_data["tracing_config"] = resource_values.get("tracing_config", {}).get("mode", "PassThrough")
    resource_data["dead_letter_config"] = resource_values.get("dead_letter_config", {}).get("target_arn", None)
    resource_data["kms_key_arn"] = resource_values.get("kms_key_arn", None)
    resource_data["file_system_config"] = resource_values.get("file_system_config", [])

    return resource_data



def handle_aws_iam_role_policy(resource_values, resource_data):
    """
    Handle parsing for aws_iam_role_policy resource type.
    """
    resource_data["role_name"] = resource_values.get("name")
    resource_data["policy"] = resource_values.get("policy")
    resource_data["description"] = resource_values.get("description", "")
    resource_data["policy_arn"] = resource_values.get("arn")
    resource_data["attached_roles"] = resource_values.get("roles", [])
    resource_data["path"] = resource_values.get("path", "/")
    resource_data["is_managed_policy"] = resource_values.get("managed_policy", False)
    resource_data["policy_version"] = resource_values.get("policy_version", "v1")
    resource_data["permissions_boundary"] = resource_values.get("permissions_boundary", None)
    resource_data["tags"] = resource_values.get("tags", {})

    return resource_data



def handle_aws_ec2_instance(resource_values, resource_data):
    """
    Handle parsing for aws_ec2_instance resource type.
    """
    resource_data["instance_type"] = resource_values.get("instance_type")
    resource_data["key_name"] = resource_values.get("key_name")
    resource_data["availability_zone"] = resource_values.get("availability_zone")
    resource_data["public_ip"] = resource_values.get("associate_public_ip_address")
    resource_data["monitoring"] = resource_values.get("monitoring", True)
    resource_data["ami_id"] = resource_values.get("ami")
    resource_data["vpc_id"] = resource_values.get("vpc_security_group_ids", [])
    resource_data["subnet_id"] = resource_values.get("subnet_id")
    resource_data["security_groups"] = resource_values.get("security_groups", [])
    resource_data["private_ip"] = resource_values.get("private_ip")
    resource_data["iam_instance_profile"] = resource_values.get("iam_instance_profile", {}).get("name")
    resource_data["instance_state"] = resource_values.get("instance_state", "unknown")
    resource_data["block_devices"] = resource_values.get("ebs_block_device", [])
    resource_data["launch_time"] = resource_values.get("launch_time", "")
    resource_data["tags"] = resource_values.get("tags", {})
    resource_data["elastic_ip"] = resource_values.get("elastic_ip")
    resource_data["user_data"] = resource_values.get("user_data", "")

    return resource_data



def handle_aws_rds_instance(resource_values, resource_data):
    """
    Handle parsing for aws_rds_instance resource type.
    """
    resource_data["instance_class"] = resource_values.get("instance_class")
    resource_data["allocated_storage"] = resource_values.get("allocated_storage")
    resource_data["engine"] = resource_values.get("engine")
    resource_data["publicly_accessible"] = resource_values.get("publicly_accessible", False)
    resource_data["db_instance_identifier"] = resource_values.get("identifier")
    resource_data["engine_version"] = resource_values.get("engine_version")
    resource_data["multi_az"] = resource_values.get("multi_az", False)
    resource_data["backup_retention_period"] = resource_values.get("backup_retention_period", 0)
    resource_data["storage_type"] = resource_values.get("storage_type", "standard")
    resource_data["vpc_security_groups"] = resource_values.get("vpc_security_group_ids", [])
    resource_data["endpoint"] = resource_values.get("endpoint", {}).get("address")
    resource_data["port"] = resource_values.get("endpoint", {}).get("port")
    resource_data["db_subnet_group"] = resource_values.get("db_subnet_group")
    resource_data["availability_zone"] = resource_values.get("availability_zone")
    resource_data["iam_database_authentication_enabled"] = resource_values.get("iam_database_authentication_enabled", False)
    resource_data["auto_minor_version_upgrade"] = resource_values.get("auto_minor_version_upgrade", True)
    resource_data["backup_window"] = resource_values.get("preferred_backup_window")
    resource_data["maintenance_window"] = resource_values.get("preferred_maintenance_window")
    resource_data["db_parameter_group"] = resource_values.get("db_parameter_group_name")
    resource_data["storage_encrypted"] = resource_values.get("storage_encrypted", False)
    resource_data["kms_key_id"] = resource_values.get("kms_key_id")
    resource_data["tags"] = resource_values.get("tags", {})

    return resource_data



def handle_aws_ebs_volume(resource_values, resource_data):
    """
    Handle parsing for aws_ebs_volume resource type.
    """
    resource_data["size"] = resource_values.get("size")
    resource_data["availability_zone"] = resource_values.get("availability_zone")
    resource_data["volume_type"] = resource_values.get("volume_type", "gp2")
    resource_data["encrypted"] = resource_values.get("encrypted", False)
    resource_data["iops"] = resource_values.get("iops")
    resource_data["snapshot_id"] = resource_values.get("snapshot_id")
    resource_data["tags"] = resource_values.get("tags", {})
    resource_data["throughput"] = resource_values.get("throughput")
    resource_data["kms_key_id"] = resource_values.get("kms_key_id")
    resource_data["multi_attach_enabled"] = resource_values.get("multi_attach_enabled", False)
    resource_data["state"] = resource_values.get("state", "available")
    resource_data["delete_on_termination"] = resource_values.get("delete_on_termination", False)

    return resource_data



def handle_aws_network_acl(resource_values, resource_data):
    """
    Handle parsing for aws_network_acl resource type.
    """
    resource_data["vpc_id"] = resource_values.get("vpc_id")
    resource_data["ingress_rules"] = []

    # Parse Ingress (Inbound) Rules
    if "ingress" in resource_values:
        for ingress_rule in resource_values["ingress"]:
            rule = {
                "rule_no": ingress_rule.get("rule_no"),
                "protocol": ingress_rule.get("protocol"),
                "action": ingress_rule.get("action"),
                "cidr_block": ingress_rule.get("cidr_block"),
                "from_port": ingress_rule.get("from_port"),
                "to_port": ingress_rule.get("to_port")
            }
            resource_data["ingress_rules"].append(rule)

    # Parse Egress (Outbound) Rules
    resource_data["egress_rules"] = []
    if "egress" in resource_values:
        for egress_rule in resource_values["egress"]:
            rule = {
                "rule_no": egress_rule.get("rule_no"),
                "protocol": egress_rule.get("protocol"),
                "action": egress_rule.get("action"),
                "cidr_block": egress_rule.get("cidr_block"),
                "from_port": egress_rule.get("from_port"),
                "to_port": egress_rule.get("to_port")
            }
            resource_data["egress_rules"].append(rule)

    resource_data["tags"] = resource_values.get("tags", {})
    resource_data["associations"] = resource_values.get("associations", [])
    resource_data["state"] = resource_values.get("state", "available")

    return resource_data




def handle_aws_autoscaling_group(resource_values, resource_data):
    """
    Handle parsing for aws_autoscaling_group resource type.
    """
    resource_data["min_size"] = resource_values.get("min_size")
    resource_data["max_size"] = resource_values.get("max_size")
    resource_data["desired_capacity"] = resource_values.get("desired_capacity")
    resource_data["availability_zones"] = resource_values.get("availability_zones", [])
    resource_data["launch_configuration"] = resource_values.get("launch_configuration")
    resource_data["launch_template"] = resource_values.get("launch_template")
    resource_data["health_check_type"] = resource_values.get("health_check_type", "EC2")
    resource_data["vpc_zone_identifier"] = resource_values.get("vpc_zone_identifier", [])
    resource_data["tags"] = resource_values.get("tags", {})
    resource_data["load_balancers"] = resource_values.get("load_balancers", [])
    resource_data["target_group_arns"] = resource_values.get("target_group_arns", [])
    resource_data["termination_policies"] = resource_values.get("termination_policies", ["Default"])
    resource_data["instance_protection"] = resource_values.get("instance_protection", False)

    return resource_data



def handle_aws_rds_cluster(resource_values, resource_data):
    """
    Handle parsing for aws_rds_cluster resource type.
    """
    resource_data["cluster_identifier"] = resource_values.get("cluster_identifier")
    resource_data["backup_retention_period"] = resource_values.get("backup_retention_period")
    resource_data["engine"] = resource_values.get("engine")
    resource_data["engine_version"] = resource_values.get("engine_version")
    resource_data["master_username"] = resource_values.get("master_username")
    resource_data["db_subnet_group"] = resource_values.get("db_subnet_group_name")
    resource_data["availability_zones"] = resource_values.get("availability_zones", [])
    resource_data["storage_encrypted"] = resource_values.get("storage_encrypted", False)
    resource_data["port"] = resource_values.get("port", 3306)  # Default port for MySQL
    resource_data["vpc_security_group_ids"] = resource_values.get("vpc_security_group_ids", [])
    resource_data["iam_database_authentication_enabled"] = resource_values.get("iam_database_authentication_enabled", False)
    resource_data["cluster_members"] = resource_values.get("cluster_members", [])
    resource_data["preferred_backup_window"] = resource_values.get("preferred_backup_window")
    resource_data["preferred_maintenance_window"] = resource_values.get("preferred_maintenance_window")
    resource_data["tags"] = resource_values.get("tags", {})

    return resource_data



def handle_aws_ecs_task_definition(resource_values, resource_data):
    """
    Handle parsing for aws_ecs_task_definition resource type.
    """
    resource_data["family"] = resource_values.get("family")
    resource_data["container_definitions"] = resource_values.get("container_definitions", [])
    resource_data["task_role_arn"] = resource_values.get("task_role_arn")
    resource_data["execution_role_arn"] = resource_values.get("execution_role_arn")
    resource_data["network_mode"] = resource_values.get("network_mode", "bridge")
    resource_data["cpu"] = resource_values.get("cpu")
    resource_data["memory"] = resource_values.get("memory")
    resource_data["requires_compatibilities"] = resource_values.get("requires_compatibilities", [])
    resource_data["volumes"] = resource_values.get("volumes", [])
    resource_data["placement_constraints"] = resource_values.get("placement_constraints", [])
    resource_data["revision"] = resource_values.get("revision")
    resource_data["tags"] = resource_values.get("tags", {})
    resource_data["ephemeral_storage"] = resource_values.get("ephemeral_storage", {}).get("size_in_gi_b")
    resource_data["log_configuration"] = resource_values.get("log_configuration", {})
    resource_data["proxy_configuration"] = resource_values.get("proxy_configuration", {})
    resource_data["pid_mode"] = resource_values.get("pid_mode")

    return resource_data



def write_json_to_file(data, output_path):
    """
    Writes the parsed JSON data into a file.
    """
    with open(output_path, 'w') as json_file:
        json.dump(data, json_file, indent=4)
    print(f"JSON output written to {output_path}")



terraform_file = input("Enter the path to your Terraform file (.tf): ")  # Taking input from user
output_json = input("Enter the name to save the output JSON (.json): ")  # Taking input from user

# Parse the Terraform file and write to JSON
parsed_data = parse_terraform(terraform_file)
write_json_to_file(parsed_data, output_json)
