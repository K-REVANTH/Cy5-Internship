def check(tf_file):
    print(f"Scanning {tf_file} for Disabling Default Security Features...")
    # Example placeholder logic for disabled default security features
    with open(tf_file, 'r') as file:
        content = file.read()
        if "disable_security" in content or "firewall = false" in content:
            print("Warning: Default security features are disabled!")
        else:
            print("Default security features are enabled.")
