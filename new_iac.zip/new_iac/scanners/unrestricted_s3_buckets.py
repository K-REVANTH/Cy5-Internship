def check(tf_file):
    print(f"Scanning {tf_file} for Unrestricted S3 Buckets...")
    # Example placeholder logic for unrestricted S3 buckets
    with open(tf_file, 'r') as file:
        content = file.read()
        if "public = true" in content:
            print("Warning: Unrestricted S3 bucket detected!")
        else:
            print("No unrestricted S3 buckets found.")
