def check(tf_file):
    print(f"Scanning {tf_file} for Improper Network ACLs...")
    # Example placeholder logic for overly permissive ACLs
    with open(tf_file, 'r') as file:
        content = file.read()
        if "0.0.0.0/0" in content:
            print("Warning: Improper Network ACL detected (Allowing all IPs)!")
        else:
            print("No improper Network ACLs found.")
