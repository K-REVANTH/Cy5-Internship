def check(tf_file):
    print(f"Scanning {tf_file} for Improper Container Configuration...")
    # Example placeholder logic for insecure container configuration
    with open(tf_file, 'r') as file:
        content = file.read()
        if "privileged = true" in content:
            print("Warning: Containers are running with root privileges!")
        else:
            print("Container configurations are secure.")
