def check(tf_file):
    print(f"Scanning {tf_file} for Exposed Management Interfaces...")
    # Example placeholder logic for exposed management interfaces
    with open(tf_file, 'r') as file:
        content = file.read()
        if "public_ip" in content or "0.0.0.0/0" in content:
            print("Warning: Management interfaces are exposed!")
        else:
            print("Management interfaces are secured.")
