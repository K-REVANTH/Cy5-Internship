def check(tf_file):
    print(f"Scanning {tf_file} for Not Following Cloud Provider Best Practices...")
    # Example placeholder logic for ignoring cloud provider best practices
    with open(tf_file, 'r') as file:
        content = file.read()
        if "aws_well_architected" not in content and "azure_security_center" not in content:
            print("Warning: Cloud provider best practices are not followed!")
        else:
            print("Cloud provider best practices are being followed.")
