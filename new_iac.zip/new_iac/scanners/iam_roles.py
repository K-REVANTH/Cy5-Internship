def check(tf_file):
    print(f"Scanning {tf_file} for IAM Role Misconfigurations...")
    # Example placeholder logic for excessive IAM role permissions
    with open(tf_file, 'r') as file:
        content = file.read()
        if "AdministratorAccess" in content:
            print("Warning: Excessive permissions assigned to IAM role!")
        else:
            print("IAM role permissions seem fine.")
