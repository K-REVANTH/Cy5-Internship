def check(tf_file):
    print(f"Scanning {tf_file} for Unrestricted Egress Rules...")
    # Example placeholder logic for egress rule misconfigurations
    with open(tf_file, 'r') as file:
        content = file.read()
        if "egress" in content and "0.0.0.0/0" in content:
            print("Warning: Unrestricted egress rule detected!")
        else:
            print("Egress rules are properly restricted.")
