def check(tf_file):
    print(f"Scanning {tf_file} for Disabled Logging or Monitoring...")
    # Example placeholder logic for missing logging/monitoring
    with open(tf_file, 'r') as file:
        content = file.read()
        if "logging_enabled = false" in content or "cloudtrail" not in content:
            print("Warning: Logging/monitoring is disabled or missing!")
        else:
            print("Logging and monitoring are properly configured.")
