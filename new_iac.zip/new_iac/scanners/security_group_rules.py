def check(tf_file):
    print(f"Scanning {tf_file} for Incorrect Security Group Rules...")
    # Logic to scan for overly permissive security group rules
    # Example placeholder logic
    with open(tf_file, 'r') as file:
        content = file.read()
        if "0.0.0.0/0" in content and ("22" in content or "80" in content):
            print("Warning: Insecure security group rules detected!")
        else:
            print("No insecure security group rules found.")
