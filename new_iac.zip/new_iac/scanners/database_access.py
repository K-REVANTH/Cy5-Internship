def check(tf_file):
    print(f"Scanning {tf_file} for Overly Permissive Database Access...")
    # Example placeholder logic for public database access
    with open(tf_file, 'r') as file:
        content = file.read()
        if "public = true" in content or "0.0.0.0/0" in content:
            print("Warning: Database is exposed to the internet!")
        else:
            print("Database access controls are fine.")
