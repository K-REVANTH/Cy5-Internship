def check(tf_file):
    print(f"Scanning {tf_file} for Encryption Misconfigurations...")
    # Example placeholder logic for missing encryption
    with open(tf_file, 'r') as file:
        content = file.read()
        if "encrypted = false" in content:
            print("Warning: Encryption is disabled!")
        else:
            print("Encryption configuration is fine.")
