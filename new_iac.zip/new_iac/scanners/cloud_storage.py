def check(tf_file):
    print(f"Scanning {tf_file} for Unrestricted Cloud Storage...")
    # Example placeholder logic for unsecured cloud storage
    with open(tf_file, 'r') as file:
        content = file.read()
        if "public_access = true" in content:
            print("Warning: Unrestricted cloud storage detected!")
        else:
            print("Cloud storage access controls are appropriate.")
