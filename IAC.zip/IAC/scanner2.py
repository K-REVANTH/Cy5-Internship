import hcl2
import os
import argparse
import re

def check_iam_policy(resource):
    """
    Check if the IAM policy is too permissive (e.g., contains '*').
    """
    print(f"Checking IAM Policy: {resource}")  # Debugging output
    if resource.get("type") == "aws_iam_policy":
        policy = resource.get("values", {}).get("policy", "")
        if '*' in policy:
            return True
    return False

def check_encryption(resource):
    """
    Check if the resource requires encryption but is not encrypted.
    """
    print(f"Checking Encryption: {resource}")  # Debugging output
    if resource.get("type") == "aws_s3_bucket":
        if not resource.get("values", {}).get("server_side_encryption_configuration"):
            return True
    return False

def check_cloudwatch_logging(resource):
    """
    Check if CloudWatch logging is enabled for RDS instances.
    """
    print(f"Checking CloudWatch Logging: {resource}")  # Debugging output
    if resource.get("type") == "aws_rds_instance":
        if not resource.get("values", {}).get("monitoring_interval"):
            return True
    return False
def check_public_s3_buckets(resource):
    """
    Check if the resource is an S3 bucket with public access.
    """
    print(f"Checking S3 Bucket: {resource}")  # Debugging output
    if resource.get("type") == "aws_s3_bucket":
        if resource.get("values", {}).get("acl") in ["public-read", "public-write"]:
            return True
    return False

def check_open_security_groups(resource):
    """
    Check if the resource is a security group with open inbound rules.
    """
    print(f"Checking Security Group: {resource}")  # Debugging output
    if resource.get("type") == "aws_security_group":
        for ingress in resource.get("values", {}).get("ingress", []):
            if ingress.get("cidr_blocks") == ["0.0.0.0/0"]:
                return True
    return False

def check_public_rds_instances(resource):
    """
    Check if the resource is an RDS instance that is publicly accessible.
    """
    print(f"Checking RDS Instance: {resource}")  # Debugging output
    if resource.get("type") == "aws_rds_instance":
        if resource.get("values", {}).get("publicly_accessible"):
            return True
    return False

def scan_terraform_file(file_path):
    """
    Scan the Terraform file for misconfigurations.
    """
    with open(file_path, 'r') as f:
        terraform_content = hcl2.load(f)

    print("\nTERRAFORM CONTENT LOADED:\n", terraform_content)  # Debugging output

    misconfigurations = []
    
    # Iterate through the resources correctly
    for resource_group in terraform_content.get('resource', []):
        for resource_type, resources in resource_group.items():
            for resource_name, properties in resources.items():
                # Create a resource object for checking
                resource = {"type": resource_type, "values": properties}

                # Check for misconfigurations
                if check_public_s3_buckets(resource):
                    misconfigurations.append(f"Public S3 Bucket found: {resource_name}")
                if check_open_security_groups(resource):
                    misconfigurations.append(f"Open Security Group found: {resource_name}")
                if check_public_rds_instances(resource):
                    misconfigurations.append(f"Public RDS Instance found: {resource_name}")
                if check_iam_policy(resource):
                    misconfigurations.append(f"Too permissive IAM Policy found: {resource_name}")
                if check_encryption(resource):
                    misconfigurations.append(f"Unencrypted S3 Bucket found: {resource_name}")
                if check_cloudwatch_logging(resource):
                    misconfigurations.append(f"CloudWatch logging not enabled for RDS Instance: {resource_name}")

    return misconfigurations


if __name__ == "__main__":
    # Setup argument parser
    parser = argparse.ArgumentParser(description='Scan Terraform files for misconfigurations.')
    parser.add_argument('terraform_file', type=str, help='Path to the Terraform file to scan.')

    args = parser.parse_args()

    # Scan for misconfigurations
    misconfigurations = scan_terraform_file(args.terraform_file)

    # Report findings
    if misconfigurations:
        print("\nMISCONFIGURATIONS FOUND:")
        for issue in misconfigurations:
            print(issue)
    else:
        print("No misconfigurations found.")
