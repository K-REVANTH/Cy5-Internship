import hcl2
import json
import os
import argparse

# Define misconfiguration checks for JSON-based Terraform Plan
def check_open_outbound_security_groups(resource):
    """Check if a security group allows unrestricted outbound traffic."""
    if resource.get("type") == "aws_security_group":
        for egress in resource.get("values", {}).get("egress", []):
            if egress.get("cidr_blocks") == ["0.0.0.0/0"]:
                return True
    return False

def check_weak_s3_encryption(resource):
    """Check if S3 bucket is using weak encryption."""
    if resource.get("type") == "aws_s3_bucket":
        encryption = resource.get("values", {}).get("server_side_encryption_configuration", {})
        if encryption and encryption.get("rule", {}).get("apply_server_side_encryption_by_default", {}).get("sse_algorithm") != "AES256":
            return True
    return False

def check_public_ec2_instance(resource):
    """Check if an EC2 instance has a public IP without proper configurations."""
    if resource.get("type") == "aws_instance":
        if resource.get("values", {}).get("associate_public_ip_address"):
            return True
    return False

def check_rds_backup_configuration(resource):
    """Check if RDS instances have automated backups disabled."""
    if resource.get("type") == "aws_rds_instance":
        if not resource.get("values", {}).get("backup_retention_period"):
            return True
    return False

def check_overly_broad_iam_role(resource):
    """Check if IAM roles have overly broad permissions."""
    if resource.get("type") == "aws_iam_role":
        policies = resource.get("values", {}).get("assume_role_policy", "")
        if "*" in policies:
            return True
    return False

def check_mfa_enabled(resource):
    """Check if MFA is not enabled for IAM users."""
    if resource.get("type") == "aws_iam_user":
        if not resource.get("values", {}).get("mfa_devices"):
            return True
    return False

def check_over_provisioned_ebs(resource):
    """Check if EBS volumes are over-provisioned."""
    if resource.get("type") == "aws_ebs_volume":
        if resource.get("values", {}).get("size", 0) > 500:  # Example threshold
            return True
    return False

def check_s3_versioning(resource):
    """Check if S3 bucket versioning is disabled."""
    if resource.get("type") == "aws_s3_bucket":
        if not resource.get("values", {}).get("versioning", {}).get("enabled"):
            return True
    return False

def check_public_elasticsearch(resource):
    """Check if an Elasticsearch domain is publicly accessible."""
    if resource.get("type") == "aws_elasticsearch_domain":
        if resource.get("values", {}).get("access_policies", "") == "*":
            return True
    return False

def check_unused_ebs_volumes(resource):
    """Check for unattached EBS volumes."""
    if resource.get("type") == "aws_ebs_volume":
        if not resource.get("values", {}).get("attachments"):
            return True
    return False

def check_vpc_peering(resource):
    """Check for non-active VPC peering connections."""
    if resource.get("type") == "aws_vpc_peering_connection":
        if resource.get("values", {}).get("accept_status") != "active":
            return True
    return False

# Define misconfiguration checks for HCL-based main2.tf files
def check_iam_policy(resource):
    """Check if the IAM policy is too permissive (e.g., contains '*')."""
    if resource.get("type") == "aws_iam_policy":
        policy = resource.get("values", {}).get("policy", "")
        if '*' in policy:
            return True
    return False

def check_encryption(resource):
    """Check if the resource requires encryption but is not encrypted."""
    if resource.get("type") == "aws_s3_bucket":
        if not resource.get("values", {}).get("server_side_encryption_configuration"):
            return True
    return False

def check_cloudwatch_logging(resource):
    """Check if CloudWatch logging is enabled for RDS instances."""
    if resource.get("type") == "aws_rds_instance":
        if not resource.get("values", {}).get("monitoring_interval"):
            return True
    return False

def check_public_s3_buckets(resource):
    """Check if the resource is an S3 bucket with public access."""
    if resource.get("type") == "aws_s3_bucket":
        if resource.get("values", {}).get("acl") in ["public-read", "public-write"]:
            return True
    return False

def check_open_security_groups(resource):
    """Check if the resource is a security group with open inbound rules."""
    if resource.get("type") == "aws_security_group":
        for ingress in resource.get("values", {}).get("ingress", []):
            if ingress.get("cidr_blocks") == ["0.0.0.0/0"]:
                return True
    return False

def check_public_rds_instances(resource):
    """Check if the resource is an RDS instance that is publicly accessible."""
    if resource.get("type") == "aws_rds_instance":
        if resource.get("values", {}).get("publicly_accessible"):
            return True
    return False

# Function to scan JSON-based Terraform Plan
def scan_terraform_plan(terraform_plan):
    all_issues = {}
    for resource in terraform_plan.get("resources", []):
        resource_issues = []
        if check_open_outbound_security_groups(resource):
            resource_issues.append("Security Group allows unrestricted outbound traffic.")
        if check_weak_s3_encryption(resource):
            resource_issues.append("S3 Bucket uses weak encryption.")
        if check_public_ec2_instance(resource):
            resource_issues.append("EC2 instance has a public IP address without proper security.")
        if check_rds_backup_configuration(resource):
            resource_issues.append("RDS instance has automated backups disabled.")
        if check_overly_broad_iam_role(resource):
            resource_issues.append("IAM Role has overly broad permissions.")
        if check_mfa_enabled(resource):
            resource_issues.append("IAM User does not have MFA enabled.")
        if check_over_provisioned_ebs(resource):
            resource_issues.append("EBS volume is over-provisioned.")
        if check_s3_versioning(resource):
            resource_issues.append("S3 Bucket versioning is disabled.")
        if check_public_elasticsearch(resource):
            resource_issues.append("Elasticsearch domain is publicly accessible.")
        if check_unused_ebs_volumes(resource):
            resource_issues.append("EBS volume is unattached.")
        if check_vpc_peering(resource):
            resource_issues.append("VPC Peering connection is not active.")
        
        if resource_issues:
            all_issues[resource.get("address")] = resource_issues
    return all_issues

# Function to scan HCL-based main2.tf files
def scan_terraform_file(file_path):
    with open(file_path, 'r') as f:
        terraform_content = hcl2.load(f)
    
    misconfigurations = []
    for resource_group in terraform_content.get('resource', []):
        for resource_type, resources in resource_group.items():
            for resource_name, properties in resources.items():
                resource = {"type": resource_type, "values": properties}

                if check_public_s3_buckets(resource):
                    misconfigurations.append(f"Public S3 Bucket found: {resource_name}")
                if check_open_security_groups(resource):
                    misconfigurations.append(f"Open Security Group found: {resource_name}")
                if check_public_rds_instances(resource):
                    misconfigurations.append(f"Public RDS Instance found: {resource_name}")
                if check_iam_policy(resource):
                    misconfigurations.append(f"Too permissive IAM Policy found: {resource_name}")
                if check_encryption(resource):
                    misconfigurations.append(f"Unencrypted S3 Bucket found: {resource_name}")
                if check_cloudwatch_logging(resource):
                    misconfigurations.append(f"CloudWatch logging not enabled for RDS Instance: {resource_name}")

    return misconfigurations

# Function to scan and load both HCL and JSON files
def load_and_scan_files(hcl_file, json_file):
    print(f"Scanning HCL file: {hcl_file}")
    hcl_issues = scan_terraform_file(hcl_file)
    
    print(f"Scanning JSON Terraform Plan file: {json_file}")
    with open(json_file, "r") as f:
        terraform_plan = json.load(f)
    json_issues = scan_terraform_plan(terraform_plan)
    
    if hcl_issues or json_issues:
        print("\nMISCONFIGURATIONS FOUND:")
        if hcl_issues:
            print("\nIn HCL file:")
            for issue in hcl_issues:
                print(issue)
        if json_issues:
            print("\nIn JSON Plan file:")
            for resource, issues in json_issues.items():
                print(f"Resource: {resource}")
                for issue in issues:
                    print(f"  - {issue}")
    else:
        print("No misconfigurations found.")

# Main function to run both scanners
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Scan Terraform files (HCL and JSON) for misconfigurations.')
    parser.add_argument('hcl_file', type=str, help='Path to the main HCL Terraform file (e.g., main2.tf).')
    parser.add_argument('json_file', type=str, help='Path to the Terraform Plan JSON file (e.g., plan.json).')
    
    args = parser.parse_args()
    
    # Run scanning on both files
    load_and_scan_files(args.hcl_file, args.json_file)
